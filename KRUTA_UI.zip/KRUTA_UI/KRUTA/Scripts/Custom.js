var childwindow = "";


var baseUrl = "http://usplvucsd090/Details/GetDocumentbyInstrumentNumber/OR/";
var currentDocNumber = "";

function openNewTab(docNumber)
{
    var fullUrl = baseUrl + docNumber;
    
    if (currentDocNumber == "")
    {
        childwindow = window.open(fullUrl);
    }
    else if (currentDocNumber != docNumber)
    {
        childwindow.location.href = fullUrl;
    }

    currentDocNumber = docNumber;
}